package com.synuppizza.synuppizza.controller;

import android.os.AsyncTask;

import com.google.gson.Gson;
import com.synuppizza.synuppizza.Listener.DataTaskListener;
import com.synuppizza.synuppizza.model.VariantResponseModel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

/**
 * Async task class to get send request for json variant data and get response back.
 */
public class JsonVariantDataTask extends AsyncTask<Void, Void, VariantResponseModel> {
    private final DataTaskListener dataTaskListener;

    public JsonVariantDataTask(DataTaskListener dataTaskListener) {
        this.dataTaskListener = dataTaskListener;
    }

    @Override
    protected VariantResponseModel doInBackground(Void... params) {
        String str = "https://api.myjson.com/bins/19u0sf";
        URLConnection urlConn;
        BufferedReader bufferedReader = null;
        try {
            URL url = new URL(str);
            urlConn = url.openConnection();
            bufferedReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));

            StringBuilder stringBuffer = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuffer.append(line);
            }

            return new Gson().fromJson(stringBuffer.toString(), VariantResponseModel.class);
        } catch (Exception ex) {
            return null;
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    protected void onPostExecute(VariantResponseModel variantResponse) {
        if (variantResponse != null) {
            dataTaskListener.onSuccess(variantResponse);

        } else {
            dataTaskListener.onError();
        }

    }
}
