package com.synuppizza.synuppizza.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.synuppizza.synuppizza.Listener.DataTaskListener;
import com.synuppizza.synuppizza.R;
import com.synuppizza.synuppizza.Util.NetworkConnectionHelper;
import com.synuppizza.synuppizza.controller.JsonVariantDataTask;
import com.synuppizza.synuppizza.model.PizzaVariantIdNameModel;
import com.synuppizza.synuppizza.model.VariantResponseModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Activity class to show Pizza variant(Crust, Size, Sauce) and option to select them on UI.
 */
public class PizzaVariantsActivity extends AppCompatActivity implements NetworkConnectionHelper.NetworkConnectionCallback {
    private NetworkConnectionHelper networkConnectionHelper;

    private ProgressBar spinner;
    private LinearLayout dataLayout;

    private final Map<PizzaVariantIdNameModel, String> pizzaVariantIdNameMap = new HashMap<>();
    private final List<String> exclusionList = new ArrayList<>();

    private Spinner crustSpinner;
    private ArrayAdapter<String> adapterCrust;
    public List<String> crustItems = new ArrayList<>();

    private Spinner sizeSpinner;
    private ArrayAdapter<String> adapterSize;
    public List<String> sizeItems = new ArrayList<>();

    private Spinner sauceSpinner;
    private ArrayAdapter<String> adapterSauce;
    private List<String> sauceItems = new ArrayList<>();

    private String crustVariantName;
    private String sizeVariantName;
    private String sauceVariantName;

    public VariantResponseModel variantResponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_variants);
        initializeView();
    }

    @Override
    public void onResume() {
        super.onResume();
        handleNetworkConnectionState();
    }

    /**
     * Receive updates on Network Availability and take proper action
     */
    private void handleNetworkConnectionState() {
        networkConnectionHelper = new NetworkConnectionHelper(this);
        networkConnectionHelper.checkNetworkConnection(this);
    }

    /**
     * Method to initialize view.
     */
    private void initializeView() {
        spinner = findViewById(R.id.progressBar);
        dataLayout = findViewById(R.id.data_layout);
    }

    private void displayData() {
        setPizzaVariantIdNameMap();

        setExclusionLIst();

        setViewDataAndListenerForCrustVariant();

        setViewDataAndListenerForSizeVariant();

        setViewDataAndListenerForSauceVariant();
    }

    /**
     * Setter for Size variant.
     */
    private void setViewDataAndListenerForSizeVariant() {
        initializeViewForSizeVariantSpinner();
        setSizeVariantSpinnerTouchListener();
        setSizeVariantSpinnerItemClickListener();
    }

    /**
     * Initialize view for size variant spinner.
     */
    private void initializeViewForSizeVariantSpinner() {
        sizeSpinner = findViewById(R.id.pizza_size);
        TextView sizeTextView = findViewById(R.id.pizza_size_text);
        sizeTextView.setText(variantResponse.getVariants().getVariantGroups().get(1).getVariantName());

        adapterSize = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, sizeItems);
        sizeSpinner.setAdapter(adapterSize);
    }

    /**
     * Setter for size variant item click listener.
     */
    private void setSizeVariantSpinnerItemClickListener() {
        sizeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sizeVariantName = sizeItems.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                /* Handling Not Required */
            }
        });
        sizeSpinner.setSelection(0, true);
    }

    /**
     * Setter for size variant touch listener.
     */
    private void setSizeVariantSpinnerTouchListener() {
        sizeSpinner.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                setData();
                sizeItems = getListAfterExcludingItems(sizeItems, crustVariantName, sauceVariantName);
                adapterSize.notifyDataSetChanged();
                return false;
            }
        });
    }

    /**
     * Setter for Sauce variant.
     */
    private void setViewDataAndListenerForSauceVariant() {
        initializeViewForSauceVariantSpinner();
        setSauceVariantSpinnerTouchListener();
        setSauceVariantSpinnerItemClickListener();
    }

    /**
     * Initialize view for sauce variant spinner.
     */
    private void initializeViewForSauceVariantSpinner() {
        sauceSpinner = findViewById(R.id.pizza_sauce);
        TextView sauceTextView = findViewById(R.id.pizza_sauce_text);

        sauceTextView.setText(variantResponse.getVariants().getVariantGroups().get(2).getVariantName());

        adapterSauce = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, sauceItems);
        sauceSpinner.setAdapter(adapterSauce);
    }

    /**
     * Setter for sauce variant item click listener.
     */
    private void setSauceVariantSpinnerItemClickListener() {
        sauceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sauceVariantName = sauceItems.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                /* Handling Not Required */
            }
        });
        sauceSpinner.setSelection(0, true);
    }

    /**
     * Setter for sauce variant touch listener.
     */
    private void setSauceVariantSpinnerTouchListener() {
        sauceSpinner.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                setData();
                sauceItems = getListAfterExcludingItems(sauceItems, crustVariantName, sizeVariantName);
                adapterSauce.notifyDataSetChanged();
                return false;
            }
        });
    }

    /**
     * Setter for crust variant.
     */
    private void setViewDataAndListenerForCrustVariant() {
        initializeViewForCrustVariantSpinner();
        setCrustVariantSpinnerTouchListener();
        setCrustVariantSpinnerItemClickListener();
    }

    /**
     * Initialize view for crust variant spinner.
     */
    private void initializeViewForCrustVariantSpinner() {
        crustSpinner = findViewById(R.id.pizza_crust);
        TextView crustTextView = findViewById(R.id.pizza_crust_text);
        crustTextView.setText(variantResponse.getVariants().getVariantGroups().get(0).getVariantName());
        adapterCrust = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, crustItems);
        crustSpinner.setAdapter(adapterCrust);
    }

    /**
     * Setter for crust variant item click listener.
     */
    private void setCrustVariantSpinnerItemClickListener() {
        crustSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                crustVariantName = crustItems.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                /* Handling Not Required */
            }
        });
        crustSpinner.setSelection(0, true);

    }

    /**
     * Setter for crust variant touch listener.
     */
    private void setCrustVariantSpinnerTouchListener() {
        crustSpinner.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                setData();
                crustItems = getListAfterExcludingItems(crustItems, sizeVariantName, sauceVariantName);
                adapterCrust.notifyDataSetChanged();
                return false;
            }
        });
    }


    /**
     * Method to set Exclusion list.
     */
    public void setExclusionLIst() {
        for (ArrayList<VariantResponseModel.ExcludeList> excludeLists : variantResponse.getVariants().getExcludeList()) {
            StringBuilder exclusionItem = new StringBuilder();
            for (VariantResponseModel.ExcludeList excludeList : excludeLists) {
                exclusionItem.append(pizzaVariantIdNameMap.get(new PizzaVariantIdNameModel(excludeList.getGroupIdExcludeList(), excludeList.getVariationIdExcludeList()))).append(" : ");
            }
            exclusionList.add(exclusionItem.toString());
        }
    }

    /**
     * Set Pizza variant, key as group id, variant id and value as name.
     */
    public void setPizzaVariantIdNameMap() {
        for (VariantResponseModel.VariantGroups variantGroups : variantResponse.getVariants().getVariantGroups()) {
            String groupId = variantGroups.getGroupId();
            for (VariantResponseModel.Variations variations : variantGroups.getVariations()) {
                pizzaVariantIdNameMap.put(new PizzaVariantIdNameModel(groupId, variations.getId()), variations.getName());
            }
        }
    }

    /**
     * Method to exclude items from exclusion list depending on selection of other variant.
     *
     * @param originalList list which need to exclude items which are in exclusion list.
     * @param variantName2 name of the first already selected variant.
     * @param variantName3 name of the second already selected variant.
     * @return list with excluding items.
     */
    public List<String> getListAfterExcludingItems(List<String> originalList, String variantName2, String variantName3) {
        final List<String> removeVariantNameList = new ArrayList<>();

        variantName2 = filterNamePartFromVariant(variantName2);
        variantName3 = filterNamePartFromVariant(variantName3);

        for (String variantName1 : originalList) {
            final String removeVariantName = variantName1;
            variantName1 = filterNamePartFromVariant(variantName1);

            for (String exclusionItems : exclusionList) {
                if ((exclusionItems.contains(variantName1) && exclusionItems.contains(variantName2)) || (exclusionItems.contains(variantName1) && exclusionItems.contains(variantName3))) {
                    removeVariantNameList.add(removeVariantName);
                }
            }
        }
        originalList.removeAll(removeVariantNameList);
        return originalList;
    }


    /**
     * Method to filter name part from variant which have name, price and isStock concatenated.
     *
     * @param variantName variant to filter.
     * @return only name of variant.
     */
    private String filterNamePartFromVariant(String variantName) {
        String patternText = "[a-z,A-Z, ]+";
        Pattern pattern = Pattern.compile(patternText);
        Matcher matcher = pattern.matcher(variantName);
        matcher.find();
        return matcher.group().trim();

    }

    /**
     * Set/reset initial data for all the variant.
     */
    public void setData() {
        crustItems.clear();
        for (VariantResponseModel.Variations variations : variantResponse.getVariants().getVariantGroups().get(0).getVariations()) {
            crustItems.add(variations.getName() + " | " + variations.getPrice() + " Rs | " + "IN STOCK: " + variations.getInStock());
        }
        sizeItems.clear();

        for (VariantResponseModel.Variations variations : variantResponse.getVariants().getVariantGroups().get(1).getVariations()) {
            sizeItems.add(variations.getName() + " | " + variations.getPrice() + " Rs | " + "IN STOCK: " + variations.getInStock());
        }
        sauceItems.clear();
        for (VariantResponseModel.Variations variations : variantResponse.getVariants().getVariantGroups().get(2).getVariations()) {
            sauceItems.add(variations.getName() + " | " + variations.getPrice() + " Rs | " + "IN STOCK: " + variations.getInStock());
        }
    }

    @Override
    public void networkAvailable() {
        Toast.makeText(getApplicationContext(), "Internet is available.", Toast.LENGTH_SHORT).show();
        spinner.setVisibility(View.VISIBLE);
        startDownloadData();
    }

    /**
     * Method to start download of json pizza  variants data.
     */
    private void startDownloadData() {
        new JsonVariantDataTask(new DataTaskListener() {
            @Override
            public void onSuccess(VariantResponseModel variantResponse) {
                PizzaVariantsActivity.this.variantResponse = variantResponse;
                setData();
                spinner.setVisibility(View.GONE);
                dataLayout.setVisibility(View.VISIBLE);
                displayData();
            }

            @Override
            public void onError() {
                Toast.makeText(getApplicationContext(), "There is an issue in downloading data.", Toast.LENGTH_SHORT).show();
                spinner.setVisibility(View.GONE);
                dataLayout.setVisibility(View.GONE);

            }
        }).execute();
    }

    @Override
    public void networkLost() {
        Toast.makeText(getApplicationContext(), "Internet is not available, Please, check your internet.", Toast.LENGTH_SHORT).show();
        spinner.setVisibility(View.GONE);
        dataLayout.setVisibility(View.GONE);
    }


    @Override
    public void onPause() {
        super.onPause();
        networkConnectionHelper.unRegisterReceiver();
        networkConnectionHelper = null;
    }
}
