package com.synuppizza.synuppizza.model;

/**
 * Class to create Pizza variant item, key as group id, variant id and value as name.
 */

public class PizzaVariantIdNameModel {
    private final String groupId;
    private final String variantId;

    public PizzaVariantIdNameModel(String groupId, String variantId) {
        this.groupId = groupId;
        this.variantId = variantId;
    }

    private String getGroupId() {
        return groupId;
    }

    private String getVariantId() {
        return variantId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PizzaVariantIdNameModel)) return false;

        PizzaVariantIdNameModel that = (PizzaVariantIdNameModel) o;

        if (!getGroupId().equals(that.getGroupId())) return false;
        return getVariantId().equals(that.getVariantId());
    }

    @Override
    public int hashCode() {
        int result = getGroupId().hashCode();
        result = 31 * result + getVariantId().hashCode();
        return result;
    }

}
