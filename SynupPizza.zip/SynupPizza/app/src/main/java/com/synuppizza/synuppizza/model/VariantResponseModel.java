package com.synuppizza.synuppizza.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Class represent response data model for json pizza variants.
 */

public class VariantResponseModel {
    public Variants getVariants() {
        return variants;
    }

    @SerializedName("variants")
    @Expose
    private Variants variants;

    public static class Variants {
        @SerializedName("variant_groups")
        @Expose
        private ArrayList<VariantGroups> variantGroups;

        @SerializedName("exclude_list")
        @Expose
        private ArrayList<ArrayList<ExcludeList>> excludeList;

        public ArrayList<VariantGroups> getVariantGroups() {
            return variantGroups;
        }

        public ArrayList<ArrayList<ExcludeList>> getExcludeList() {
            return excludeList;
        }

    }

    public static class VariantGroups {
        @SerializedName("group_id")
        @Expose
        private String groupId;

        @SerializedName("name")
        @Expose
        private String variantName;

        @SerializedName("variations")
        @Expose
        private ArrayList<Variations> variations;

        public String getGroupId() {
            return groupId;
        }

        public String getVariantName() {
            return variantName;
        }

        public ArrayList<Variations> getVariations() {
            return variations;
        }

    }

    public static class ExcludeList {
        @SerializedName("group_id")
        @Expose
        private String groupIdExcludeList;

        @SerializedName("variation_id")
        @Expose
        private String variationIdExcludeList;

        public String getGroupIdExcludeList() {
            return groupIdExcludeList;
        }

        public String getVariationIdExcludeList() {
            return variationIdExcludeList;
        }

    }

    public static class Variations {
        @SerializedName("name")
        @Expose
        private String name;

        @SerializedName("price")
        @Expose
        private int price;

        @SerializedName("default")
        @Expose
        private int defaultValue;

        @SerializedName("id")
        @Expose
        private String id;

        @SerializedName("inStock")
        @Expose
        private int inStock;

        @SerializedName("isVeg")
        @Expose
        private int isVeg;

        public String getName() {
            return name;
        }

        public int getPrice() {
            return price;
        }

        public int getDefaultValue() {
            return defaultValue;
        }

        public String getId() {
            return id;
        }

        public int getInStock() {
            return inStock;
        }

        public int getIsVeg() {
            return isVeg;
        }


    }
}
