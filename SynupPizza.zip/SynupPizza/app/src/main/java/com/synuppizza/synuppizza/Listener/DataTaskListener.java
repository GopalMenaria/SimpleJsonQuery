package com.synuppizza.synuppizza.Listener;

import com.synuppizza.synuppizza.model.VariantResponseModel;

/**
 * Interface to handle async task.
 */

public interface DataTaskListener {
    void onSuccess(VariantResponseModel variantResponse);

    void onError();
}
