package com.synuppizza.synuppizza;

import com.google.gson.Gson;
import com.synuppizza.synuppizza.model.VariantResponseModel;
import com.synuppizza.synuppizza.view.PizzaVariantsActivity;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertEquals;

/**
 * Test class to test critical method of PizzaVariantActivity class.
 */

public class PizzaVariantActivityTest {
    private final PizzaVariantsActivity pizzaVariantsActivity = new PizzaVariantsActivity();

    @Test
    public void testForCrustVariant() throws Exception {
        final String expectedItems = "[Thin | 0 Rs | IN STOCK: 1, Thick | 0 Rs | IN STOCK: 1]";
        final String actualItems = Arrays.toString(pizzaVariantsActivity.getListAfterExcludingItems(pizzaVariantsActivity.crustItems, "Small | 0 Rs| IN STOCK:1", "Tomato | 20 Rs| IN STOCK:1").toArray());
        assertEquals(expectedItems, actualItems);
    }

    @Test
    public void testForSizeVariant() throws Exception {
        final String expectedItems = "[Medium | 100 Rs | IN STOCK: 1, :Large | 200 Rs | IN STOCK: 1]";
        final String actualItems = Arrays.toString(pizzaVariantsActivity.getListAfterExcludingItems(pizzaVariantsActivity.sizeItems, "Cheese burst | 100 Rs| IN STOCK:1", "Tomato | 20 Rs| IN STOCK:1").toArray());
        assertEquals(expectedItems, actualItems);
    }

    @Test
    public void testForSauceVariant() throws Exception {
        final String expectedItems = "[Thin | 0 Rs | IN STOCK: 1, Thick | 0 Rs | IN STOCK: 1]";
        final String actualItems = Arrays.toString(pizzaVariantsActivity.getListAfterExcludingItems(pizzaVariantsActivity.crustItems, "Thin | 0 Rs| IN STOCK:1", "Small | 0 Rs| IN STOCK:1").toArray());
        assertEquals(expectedItems, actualItems);
    }

    @Test
    public void testForCrustVariantWithMoreData() throws Exception {
        initializeData("{\"variants\":{\"variant_groups\":[{\"group_id\":\"1\",\"name\":\"Crust\",\"variations\":[{\"name\":\"Thin\",\"price\":0,\"default\":1,\"id\":\"1\",\"inStock\":1},{\"name\":\"Thick\",\"price\":0,\"default\":0,\"id\":\"2\",\"inStock\":1,\"isVeg\":1},{\"name\":\"Cheese burst\",\"price\":100,\"default\":0,\"id\":\"3\",\"inStock\":1,\"isVeg\":1},{\"name\":\"Double cheese\",\"price\":200,\"default\":0,\"id\":\"4\",\"inStock\":1,\"isVeg\":1}]},{\"group_id\":\"2\",\"name\":\"Size\",\"variations\":[{\"name\":\"Small\",\"price\":0,\"default\":1,\"id\":\"10\",\"inStock\":1,\"isVeg\":0},{\"name\":\"Medium\",\"price\":100,\"default\":0,\"id\":\"11\",\"inStock\":1,\"isVeg\":1},{\"name\":\":Large\",\"price\":200,\"default\":0,\"id\":\"12\",\"inStock\":1,\"isVeg\":0}]},{\"group_id\":\"3\",\"name\":\"Sauce\",\"variations\":[{\"name\":\"Manchurian\",\"price\":20,\"default\":0,\"id\":\"20\",\"inStock\":1,\"isVeg\":0},{\"name\":\"Tomato\",\"price\":20,\"default\":0,\"id\":\"21\",\"inStock\":1,\"isVeg\":1},{\"name\":\"Mustard\",\"price\":20,\"default\":0,\"id\":\"22\",\"inStock\":1,\"isVeg\":0}]}],\"exclude_list\":[[{\"group_id\":\"1\",\"variation_id\":\"3\"},{\"group_id\":\"2\",\"variation_id\":\"10\"}],[{\"group_id\":\"2\",\"variation_id\":\"10\"},{\"group_id\":\"3\",\"variation_id\":\"22\"}],[{\"group_id\":\"3\",\"variation_id\":\"21\"},{\"group_id\":\"1\",\"variation_id\":\"2\"}]]}}");
        final String expectedItems = "[Thin | 0 Rs | IN STOCK: 1, Double cheese | 200 Rs | IN STOCK: 1]";
        final String actualItems = Arrays.toString(pizzaVariantsActivity.getListAfterExcludingItems(pizzaVariantsActivity.crustItems, "Small | 0 Rs| IN STOCK:1", "Tomato | 20 Rs| IN STOCK:1").toArray());
        assertEquals(expectedItems, actualItems);
    }

    /**
     * Method to initialize data
     */
    private void initializeData(final String jsonData) {
        pizzaVariantsActivity.variantResponse = new Gson().fromJson(jsonData, VariantResponseModel.class);
        pizzaVariantsActivity.setPizzaVariantIdNameMap();
        pizzaVariantsActivity.setExclusionLIst();
        pizzaVariantsActivity.setData();
    }

    @Before
    public void setUp() throws Exception {
        initializeData("{\"variants\":{\"variant_groups\":[{\"group_id\":\"1\",\"name\":\"Crust\",\"variations\":[{\"name\":\"Thin\",\"price\":0,\"default\":1,\"id\":\"1\",\"inStock\":1},{\"name\":\"Thick\",\"price\":0,\"default\":0,\"id\":\"2\",\"inStock\":1,\"isVeg\":1},{\"name\":\"Cheese burst\",\"price\":100,\"default\":0,\"id\":\"3\",\"inStock\":1,\"isVeg\":1}]},{\"group_id\":\"2\",\"name\":\"Size\",\"variations\":[{\"name\":\"Small\",\"price\":0,\"default\":1,\"id\":\"10\",\"inStock\":1,\"isVeg\":0},{\"name\":\"Medium\",\"price\":100,\"default\":0,\"id\":\"11\",\"inStock\":1,\"isVeg\":1},{\"name\":\":Large\",\"price\":200,\"default\":0,\"id\":\"12\",\"inStock\":1,\"isVeg\":0}]},{\"group_id\":\"3\",\"name\":\"Sauce\",\"variations\":[{\"name\":\"Manchurian\",\"price\":20,\"default\":0,\"id\":\"20\",\"inStock\":1,\"isVeg\":0},{\"name\":\"Tomato\",\"price\":20,\"default\":0,\"id\":\"21\",\"inStock\":1,\"isVeg\":1},{\"name\":\"Mustard\",\"price\":20,\"default\":0,\"id\":\"22\",\"inStock\":1,\"isVeg\":0}]}],\"exclude_list\":[[{\"group_id\":\"1\",\"variation_id\":\"3\"},{\"group_id\":\"2\",\"variation_id\":\"10\"}],[{\"group_id\":\"2\",\"variation_id\":\"10\"},{\"group_id\":\"3\",\"variation_id\":\"22\"}]]}}");
    }
}
